import React from "react";
import { Sparkles, ArrowUp } from "lucide-react";

export default function Footer() {
  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="relative border-t border-white/5 bg-zinc-950 py-12 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-96 h-24 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 relative z-10 text-center md:text-left">
        
        {/* Brand identity */}
        <div className="flex flex-col space-y-2 items-center md:items-start">
          <div className="flex items-center space-x-2 font-display font-bold text-xl tracking-wide text-white">
            <span className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(59,130,246,1)]" />
            <span>Calvent</span>
          </div>
          <p className="text-gray-500 text-xs font-light">
            © {new Date().getFullYear()} Calvent Inc. All rights reserved.
          </p>
        </div>

        {/* Navigation links requested */}
        <div className="flex flex-wrap justify-center gap-8 text-xs font-mono tracking-wider text-gray-400">
          <a href="#" className="hover:text-blue-400 transition-colors">
            Privacy Policy
          </a>
          <a href="#" className="hover:text-blue-400 transition-colors">
            Terms of Service
          </a>
          <a href="mailto:support@calvent.ai" className="hover:text-blue-400 transition-colors">
            Contact
          </a>
        </div>

        {/* Scroll back to top */}
        <button
          onClick={handleScrollToTop}
          className="group flex items-center space-x-2 text-xs font-mono tracking-wider text-gray-500 hover:text-white transition-colors cursor-pointer"
        >
          <span>Back to top</span>
          <div className="w-6 h-6 rounded-full border border-white/10 flex items-center justify-center group-hover:border-white/30 transition-colors">
            <ArrowUp className="w-3.5 h-3.5 group-hover:-translate-y-0.5 transition-transform" />
          </div>
        </button>

      </div>
    </footer>
  );
}
