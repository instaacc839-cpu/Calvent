import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { ArrowRight, Play, Camera, Star, Sparkles } from "lucide-react";
import GlassCard from "./GlassCard";

interface HeroProps {
  onAnalyzeClick: () => void;
  onDemoClick: () => void;
}

export default function Hero({ onAnalyzeClick, onDemoClick }: HeroProps) {
  const [activeScore, setActiveScore] = useState<number>(0);
  
  // Animate the scores to count up on load
  useEffect(() => {
    const timer = setTimeout(() => {
      setActiveScore(8.4);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const parameters = [
    { name: "Photo Quality", score: 9.2, color: "from-blue-500 to-indigo-500" },
    { name: "Lighting", score: 8.8, color: "from-blue-400 to-cyan-400" },
    { name: "Style", score: 8.1, color: "from-indigo-500 to-purple-500" },
    { name: "Expression", score: 8.0, color: "from-purple-500 to-pink-500" },
    { name: "Background", score: 6.9, color: "from-amber-500 to-orange-500" },
    { name: "Approachability", score: 7.7, color: "from-teal-500 to-emerald-500" },
  ];

  return (
    <section className="relative min-h-screen pt-32 pb-20 flex flex-col justify-center items-center overflow-hidden px-4 sm:px-6 lg:px-8">
      {/* Background Radial Glow */}
      <div className="absolute inset-0 bg-grid-pattern opacity-60 pointer-events-none" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-radial-glow pointer-events-none opacity-85" />
      
      {/* Subtle floating ambient spheres */}
      <div className="absolute top-48 left-10 w-72 h-72 bg-blue-600/5 rounded-full blur-3xl pointer-events-none animate-pulse" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-indigo-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center relative z-10">
        
        {/* Left: Text & CTA */}
        <div className="lg:col-span-7 flex flex-col space-y-8 text-center lg:text-left">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="inline-flex items-center space-x-2 bg-white/5 border border-white/10 rounded-full px-4 py-1.5 self-center lg:self-start backdrop-blur-md"
          >
            <Sparkles className="w-4 h-4 text-blue-400 animate-spin" style={{ animationDuration: "3s" }} />
            <span className="text-xs font-medium tracking-wide text-gray-300 uppercase font-mono">
              Next-Gen Vision AI Analysis
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
            className="text-4xl sm:text-5xl md:text-6xl font-display font-bold tracking-tight text-white leading-[1.1]"
          >
            See the First Impression <br className="hidden sm:inline" />
            You're <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-blue-500 to-indigo-400">Actually</span> Giving.
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1], delay: 0.3 }}
            className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto lg:mx-0 font-sans font-light leading-relaxed"
          >
            Upload a selfie or profile photo. Calvent analyzes your presentation and provides detailed, actionable feedback to help you improve your photos and profile.
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1], delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-4"
          >
            {/* Primary Action */}
            <button
              onClick={onAnalyzeClick}
              className="relative group overflow-hidden bg-blue-600 hover:bg-blue-500 text-white font-medium px-8 py-4 rounded-xl transition-all duration-300 shadow-[0_0_20px_rgba(59,130,246,0.3)] hover:shadow-[0_0_30px_rgba(59,130,246,0.5)] flex items-center justify-center space-x-2 cursor-pointer"
            >
              <div className="absolute inset-0 w-1/2 h-full bg-white/10 skew-x-[-20deg] -translate-x-full group-hover:animate-shine" />
              <Camera className="w-5 h-5 text-blue-200" />
              <span>Analyze My Photo</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>

            {/* Secondary Action */}
            <button
              onClick={onDemoClick}
              className="bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 text-white font-medium px-8 py-4 rounded-xl transition-all duration-300 flex items-center justify-center space-x-2 backdrop-blur-md cursor-pointer"
            >
              <Play className="w-4 h-4 text-gray-400 fill-gray-400 group-hover:text-white" />
              <span>View Demo</span>
            </button>
          </motion.div>

          {/* Stats Trust row */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex items-center justify-center lg:justify-start gap-6 pt-6 text-xs text-gray-500 font-mono"
          >
            <div className="flex items-center gap-1">
              <Star className="w-3.5 h-3.5 text-blue-400 fill-blue-400" />
              <Star className="w-3.5 h-3.5 text-blue-400 fill-blue-400" />
              <Star className="w-3.5 h-3.5 text-blue-400 fill-blue-400" />
              <Star className="w-3.5 h-3.5 text-blue-400 fill-blue-400" />
              <Star className="w-3.5 h-3.5 text-blue-400 fill-blue-400" />
              <span className="text-gray-400 ml-1">4.9/5 Rating</span>
            </div>
            <div className="h-4 w-[1px] bg-white/10" />
            <div>
              <span className="text-gray-400">100% Private</span>
            </div>
          </motion.div>
        </div>

        {/* Right: Glassmorphism Score Card Visualizer */}
        <div className="lg:col-span-5 relative w-full flex justify-center lg:justify-end">
          {/* Subtle colored shadow blur */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-blue-500/20 rounded-full blur-[80px] pointer-events-none" />
          
          <GlassCard className="w-full max-w-[420px] border-white/10 relative" glow delay={0.25}>
            {/* Top scanning animation row over mockup portrait */}
            <div className="relative h-48 w-full rounded-xl overflow-hidden mb-6 bg-zinc-900 border border-white/5">
              <img 
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=600&auto=format&fit=crop" 
                alt="AI Analysis Demo Profile" 
                className="w-full h-full object-cover object-center opacity-85 scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent" />
              
              {/* Premium holographic scanner wireframe */}
              <div className="absolute inset-0 bg-grid-pattern opacity-40" />
              
              {/* Laser line sweep animation */}
              <div className="absolute left-0 right-0 h-[2px] bg-blue-500/80 shadow-[0_0_15px_rgba(59,130,246,1)] animate-laser-sweep" />
              
              {/* Hologram details on top */}
              <div className="absolute top-3 left-3 bg-black/60 border border-white/10 rounded-lg px-2.5 py-1 text-[10px] font-mono uppercase tracking-widest text-blue-400 backdrop-blur-md flex items-center space-x-1">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-ping" />
                <span>AI Scanners: active</span>
              </div>
              <div className="absolute bottom-3 left-3 text-left">
                <p className="text-white text-xs font-semibold tracking-wide">Sophia Chen</p>
                <p className="text-gray-400 text-[10px] font-mono">Creative Strategist</p>
              </div>
            </div>

            {/* Score circle layout */}
            <div className="flex items-center justify-between mb-6">
              <div className="text-left">
                <h3 className="text-white text-sm font-semibold tracking-wide">Impression Summary</h3>
                <p className="text-xs text-gray-400 font-mono">Profile Portrait #01</p>
              </div>
              
              {/* Circular score ring */}
              <div className="relative w-20 h-20 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90">
                  {/* Background track circle */}
                  <circle
                    cx="40"
                    cy="40"
                    r="34"
                    className="stroke-zinc-800"
                    strokeWidth="5"
                    fill="transparent"
                  />
                  {/* Score filled circle */}
                  <motion.circle
                    cx="40"
                    cy="40"
                    r="34"
                    className="stroke-blue-500"
                    strokeWidth="5"
                    fill="transparent"
                    strokeDasharray={2 * Math.PI * 34}
                    initial={{ strokeDashoffset: 2 * Math.PI * 34 }}
                    animate={{ strokeDashoffset: 2 * Math.PI * 34 * (1 - activeScore / 10) }}
                    transition={{ duration: 1.5, ease: "easeOut" }}
                    strokeLinecap="round"
                  />
                </svg>
                {/* Absolute overall score labels */}
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-lg font-bold text-white font-display leading-none">8.4</span>
                  <span className="text-[9px] text-gray-500 font-mono tracking-tighter uppercase mt-0.5">Overall</span>
                </div>
              </div>
            </div>

            {/* Parameter score bars */}
            <div className="space-y-3 mb-6">
              {parameters.map((param, index) => (
                <div key={param.name} className="flex flex-col text-left">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-gray-300 font-light">{param.name}</span>
                    <span className="text-gray-400 font-mono font-medium">{param.score.toFixed(1)}</span>
                  </div>
                  {/* Visual progress bar */}
                  <div className="w-full h-1 bg-zinc-800 rounded-full overflow-hidden">
                    <motion.div
                      className={`h-full bg-gradient-to-r ${param.color}`}
                      initial={{ width: "0%" }}
                      animate={{ width: `${param.score * 10}%` }}
                      transition={{ duration: 1.2, ease: "easeOut", delay: 0.1 * index }}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* AI Advisor Comment Box */}
            <div className="bg-white/5 border border-white/5 rounded-xl p-4 text-left relative overflow-hidden">
              <div className="absolute top-0 right-0 p-2 opacity-10">
                <Sparkles className="w-10 h-10 text-white" />
              </div>
              <h4 className="text-xs font-semibold text-blue-400 uppercase tracking-widest font-mono mb-1.5 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Calvent Advisor
              </h4>
              <p className="text-gray-300 text-xs font-light leading-relaxed">
                "Your lighting is excellent and your expression appears confident. The main factor reducing your score is the distracting background. A cleaner background and a slightly higher camera angle would create a stronger first impression."
              </p>
            </div>
          </GlassCard>
        </div>

      </div>
    </section>
  );
}
