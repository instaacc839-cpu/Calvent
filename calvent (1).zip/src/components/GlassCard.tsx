import React from "react";
import { motion } from "motion/react";

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  hoverEffect?: boolean;
  glow?: boolean;
  id?: string;
  delay?: number;
  key?: any;
}

export default function GlassCard({
  children,
  className = "",
  hoverEffect = false,
  glow = false,
  id,
  delay = 0,
}: GlassCardProps) {
  return (
    <motion.div
      id={id}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1], delay }}
      className={`
        glass-card relative rounded-2xl overflow-hidden p-6
        ${hoverEffect ? "glass-card-hover" : ""}
        ${className}
      `}
    >
      {/* Subtle glow effect behind card */}
      {glow && (
        <div className="absolute -top-12 -left-12 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
      )}
      
      {/* Premium top border highlight */}
      <div className="absolute inset-x-0 top-0 h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      
      {children}
    </motion.div>
  );
}
