import React from "react";
import { motion } from "motion/react";
import { 
  Cpu, FileSpreadsheet, Sparkles, Sliders, Zap, ShieldAlert,
  Brain, FileText, Compass, Users, Gauge, Lock
} from "lucide-react";
import GlassCard from "./GlassCard";

export default function Features() {
  const featuresList = [
    {
      title: "AI-Powered Image Analysis",
      description: "Our proprietary vision models scan hundreds of biometrics, contrast values, facial lines, angles, and color distributions in parallel.",
      icon: Brain,
      color: "text-blue-400 bg-blue-500/10 border-blue-500/10",
    },
    {
      title: "Detailed Explanations",
      description: "Get granular, professional reports breaking down your ratings so you understand exactly why you scored what you did.",
      icon: FileText,
      color: "text-indigo-400 bg-indigo-500/10 border-indigo-500/10",
    },
    {
      title: "Personalized Improvement Tips",
      description: "Receive exact suggestions on camera angles, lighting directions, top-wear style patterns, background depth, and posture shifts.",
      icon: Sparkles,
      color: "text-purple-400 bg-purple-500/10 border-purple-500/10",
    },
    {
      title: "Multiple Photo Comparison",
      description: "Upload up to 5 pictures side-by-side. Find out which specific headshot drives the ultimate professional connection or social warmth.",
      icon: Users,
      color: "text-cyan-400 bg-cyan-500/10 border-cyan-500/10",
    },
    {
      title: "Ultra-Fast Analysis",
      description: "No long queues. Backed by multi-modal LLM cloud clusters, your detailed portfolio audit is generated and delivered in under 3 seconds.",
      icon: Gauge,
      color: "text-emerald-400 bg-emerald-500/10 border-emerald-500/10",
    },
    {
      title: "Privacy-First Processing",
      description: "Your pictures are strictly yours. All submitted portraits are parsed directly in encrypted RAM pipelines and deleted immediately.",
      icon: Lock,
      color: "text-rose-400 bg-rose-500/10 border-rose-500/10",
    },
  ];

  return (
    <section id="features" className="relative py-24 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Background Visual Grids */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-radial-glow opacity-60 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="text-xs font-semibold text-blue-500 uppercase tracking-widest font-mono mb-3">
            Core Technology
          </h2>
          <p className="text-3xl sm:text-4xl font-bold font-display text-white tracking-tight">
            The Technology Built to Optimize Your Presence
          </p>
          <p className="text-gray-400 text-sm sm:text-base font-light mt-4">
            Calvent packages advanced optical machine learning and portrait consulting principles into a single seamless, high-speed dashboard.
          </p>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuresList.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <GlassCard
                key={feature.title}
                hoverEffect
                className="flex flex-col text-left h-full border-white/5"
                delay={0.1 * idx}
              >
                {/* Icon box */}
                <div className={`w-12 h-12 rounded-xl border flex items-center justify-center mb-6 ${feature.color}`}>
                  <Icon className="w-6 h-6" />
                </div>

                {/* Info titles */}
                <h3 className="text-lg font-bold text-white mb-2 font-display">
                  {feature.title}
                </h3>
                
                <p className="text-gray-400 text-xs sm:text-sm font-light leading-relaxed">
                  {feature.description}
                </p>
              </GlassCard>
            );
          })}
        </div>

      </div>
    </section>
  );
}
