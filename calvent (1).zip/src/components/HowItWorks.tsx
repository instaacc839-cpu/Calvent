import React from "react";
import { motion } from "motion/react";
import { UploadCloud, Cpu, Sparkles, CheckCircle2, TrendingUp } from "lucide-react";
import GlassCard from "./GlassCard";

export default function HowItWorks() {
  const steps = [
    {
      num: "01",
      title: "Upload",
      description: "Upload 1–5 selfies or profile photos.",
      details: "Compatible with JPEG, PNG, or WebP files. Upload portraits, selfies, or team directories to check individual and cohesive team scores.",
      icon: UploadCloud,
      color: "text-blue-400 bg-blue-500/10 border-blue-500/20",
    },
    {
      num: "02",
      title: "AI Analysis",
      description: "Calvent evaluates your presentation in depth.",
      details: [
        "Photo quality & sharpness",
        "Lighting setup & shadows",
        "Facial expression & smirk",
        "Eye contact & gaze warmth",
        "Outfit style & grooming",
        "Background details & clutter",
        "Overall presentation aura",
      ],
      icon: Cpu,
      color: "text-indigo-400 bg-indigo-500/10 border-indigo-500/20",
    },
    {
      num: "03",
      title: "Improve",
      description: "Apply custom, highly actionable feedback.",
      details: "Receive clear, detailed explanations for every parameters score and highly personalized suggestions you can actually apply to stand out.",
      icon: TrendingUp,
      color: "text-cyan-400 bg-cyan-500/10 border-cyan-500/20",
    },
  ];

  return (
    <section id="how-it-works" className="relative py-24 px-4 sm:px-6 lg:px-8 bg-zinc-950/40 border-y border-zinc-900 overflow-hidden">
      {/* Background visual glow */}
      <div className="absolute top-1/2 left-1/3 w-[500px] h-[500px] bg-indigo-500/5 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Header Title */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="text-xs font-semibold text-blue-500 uppercase tracking-widest font-mono mb-3">
            Engineered For Excellence
          </h2>
          <p className="text-3xl sm:text-4xl font-bold font-display text-white tracking-tight">
            How Calvent Evaluates Your First Impression
          </p>
          <p className="text-gray-400 text-sm sm:text-base font-light mt-4 leading-relaxed">
            From professional corporate headshots to casual social profile avatars, our multi-modal AI breaks down key micro-factors to help you convey ultimate capability, trustworthiness, and approachability.
          </p>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <GlassCard
                key={step.title}
                hoverEffect
                className="flex flex-col text-left h-full border-white/5 relative"
                delay={0.15 * idx}
              >
                {/* Step number label */}
                <div className="absolute top-6 right-6 font-mono text-3xl font-black text-white/5 select-none">
                  {step.num}
                </div>

                {/* Step Icon */}
                <div className={`w-12 h-12 rounded-xl border flex items-center justify-center mb-6 ${step.color}`}>
                  <Icon className="w-6 h-6" />
                </div>

                {/* Step Info */}
                <h3 className="text-xl font-bold text-white mb-2 font-display flex items-center gap-2">
                  <span>{step.title}</span>
                </h3>
                
                <p className="text-gray-300 text-sm font-medium mb-4">
                  {step.description}
                </p>

                {/* Custom details display */}
                {Array.isArray(step.details) ? (
                  <div className="mt-auto pt-2 border-t border-white/5">
                    <p className="text-gray-500 text-[10px] font-mono uppercase tracking-widest mb-3">Evaluations include:</p>
                    <ul className="grid grid-cols-1 gap-2">
                      {step.details.map((detail) => (
                        <li key={detail} className="flex items-center space-x-2 text-xs text-gray-400 font-light">
                          <CheckCircle2 className="w-3.5 h-3.5 text-blue-500/80 shrink-0" />
                          <span>{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : (
                  <p className="text-gray-400 text-xs font-light leading-relaxed mt-auto pt-4 border-t border-white/5">
                    {step.details}
                  </p>
                )}
              </GlassCard>
            );
          })}
        </div>

      </div>
    </section>
  );
}
