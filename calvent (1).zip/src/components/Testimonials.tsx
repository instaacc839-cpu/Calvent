import React from "react";
import { motion } from "motion/react";
import { Star, Quote } from "lucide-react";
import GlassCard from "./GlassCard";

export default function Testimonials() {
  const reviews = [
    {
      name: "Marcus Sterling",
      role: "Managing Director, Sterling Group",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=300&auto=format&fit=crop",
      quote: "Before Calvent, I had no idea why my LinkedIn headshot felt slightly flat. Calvent's lighting analysis caught a heavy shadow pattern underneath my eyes. After moving 2 steps closer to the window, my approachability score jumped. My connection rate rose 24% in weeks.",
      rating: 5,
    },
    {
      name: "Elena Rostova",
      role: "Founder, Bloom Marketing",
      avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=300&auto=format&fit=crop",
      quote: "As a creative consultant, I wanted my avatar to feel premium but approachable. Calvent broke down my styling, grooming, and background contrast. The specific tip about using portrait depth-of-field was a game-changer. Absolutely brilliant SaaS.",
      rating: 5,
    },
    {
      name: "Devon Cho",
      role: "Tech Recruiter & HR Lead",
      avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=300&auto=format&fit=crop",
      quote: "I recommend Calvent to every executive candidate I represent. In recruiting, first impressions are critical. Most people use outdated, dark, or busy crop photos. Calvent gives them immediate, actionable steps to look polished and qualified. 10/10.",
      rating: 5,
    },
  ];

  return (
    <section id="testimonials" className="relative py-24 px-4 sm:px-6 lg:px-8 bg-zinc-950/40 border-y border-zinc-900 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-1/2 left-1/4 w-[500px] h-[500px] bg-blue-600/5 rounded-full blur-[120px] pointer-events-none" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-xs font-semibold text-blue-500 uppercase tracking-widest font-mono mb-3">
            Real Impact
          </h2>
          <p className="text-3xl sm:text-4xl font-bold font-display text-white tracking-tight">
            Loved By Professional Leaders Everywhere
          </p>
          <p className="text-gray-400 text-sm sm:text-base font-light mt-4">
            Hear from corporate executives, tech founders, and modern consultants who upgraded their directory presentation using Calvent.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review, idx) => (
            <GlassCard
              key={review.name}
              hoverEffect
              className="flex flex-col text-left justify-between h-full border-white/5 bg-zinc-900/10"
              delay={0.15 * idx}
            >
              {/* Star line */}
              <div className="flex items-center space-x-1 mb-6">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-amber-400 fill-amber-400" />
                ))}
              </div>

              {/* Quote bubble */}
              <div className="relative mb-8">
                <Quote className="absolute -top-4 -left-3 w-8 h-8 text-white/5 pointer-events-none shrink-0" />
                <p className="text-gray-300 text-sm font-light leading-relaxed relative z-10 italic">
                  "{review.quote}"
                </p>
              </div>

              {/* Client avatar row */}
              <div className="flex items-center space-x-4 pt-4 border-t border-white/5">
                <div className="w-10 h-10 rounded-full overflow-hidden border border-white/10 shrink-0">
                  <img src={review.avatar} alt={review.name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <h4 className="text-white text-sm font-semibold">{review.name}</h4>
                  <p className="text-gray-500 text-xs font-light">{review.role}</p>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>

      </div>
    </section>
  );
}
