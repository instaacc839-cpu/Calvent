import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Upload, Camera, RefreshCw, Sparkles, Check, CheckCircle2, 
  ChevronRight, AlertCircle, Eye, Sun, Shield, Layers, HelpCircle,
  TrendingUp
} from "lucide-react";
import GlassCard from "./GlassCard";
import { demoPresets } from "../data/demoPresets";
import { PhotoAnalysisResult, DemoPreset, ScoreDetails } from "../types";

export default function DemoSection() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisStatus, setAnalysisStatus] = useState<string>("Initializing secure environment...");
  const [activeAnalysis, setActiveAnalysis] = useState<PhotoAnalysisResult | null>(null);
  const [selectedPresetId, setSelectedPresetId] = useState<string | null>(null);
  const [activeCategoryTab, setActiveCategoryTab] = useState<string>("all");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const statusLogs = [
    "Uploading raw pixel data safely...",
    "Calibrating facial alignment & lens perspective vectors...",
    "Scanning lighting gradients, shadow contrast, and glare...",
    "Extracting micro-expression cues & confidence indexes...",
    "Segmenting background clutter, textures, and depth...",
    "Synthesizing results with Calvent First Impression Model v4.2...",
    "Generating premium actionable feedback..."
  ];

  // Handle preset clicks
  const handlePresetSelect = (preset: DemoPreset) => {
    setSelectedPresetId(preset.id);
    setSelectedFile(null);
    setPreviewUrl(preset.imageUrl);
    setIsAnalyzing(true);
    setErrorMsg(null);
    
    // Cycle through status logs quickly to simulate high-tech analysis
    let logIndex = 0;
    setAnalysisStatus(statusLogs[0]);
    const interval = setInterval(() => {
      logIndex++;
      if (logIndex < statusLogs.length) {
        setAnalysisStatus(statusLogs[logIndex]);
      } else {
        clearInterval(interval);
        setActiveAnalysis(preset.result);
        setIsAnalyzing(false);
      }
    }, 280);
  };

  // Handle local file uploads
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    // Validate file type
    if (!file.type.startsWith("image/")) {
      setErrorMsg("Please upload a valid image file (PNG, JPEG, WebP).");
      return;
    }
    // Validate size (limit 8MB)
    if (file.size > 8 * 1024 * 1024) {
      setErrorMsg("File size too large. Please upload an image under 8MB.");
      return;
    }

    setSelectedFile(file);
    setSelectedPresetId(null);
    setErrorMsg(null);
    
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    triggerImageScan(file);
  };

  // Drag and drop handlers
  const [isDragOver, setIsDragOver] = useState<boolean>(false);
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };
  const handleDragLeave = () => {
    setIsDragOver(false);
  };
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  // Trigger base64 conversion and real fetch to Express server
  const triggerImageScan = (file: File) => {
    setIsAnalyzing(true);
    
    // Set up status loading sequence
    let logIndex = 0;
    setAnalysisStatus(statusLogs[0]);
    const interval = setInterval(() => {
      logIndex = (logIndex + 1) % statusLogs.length;
      setAnalysisStatus(statusLogs[logIndex]);
    }, 450);

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64String = reader.result as string;
      try {
        const response = await fetch("/api/analyze", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            imageBase64: base64String,
            mimeType: file.type,
          }),
        });

        if (!response.ok) {
          throw new Error("Analysis failed. Server returned an error.");
        }

        const data = await response.json();
        clearInterval(interval);
        
        if (data.success && data.analysis) {
          setActiveAnalysis(data.analysis);
        } else {
          throw new Error(data.error || "Unexpected analysis response format.");
        }
      } catch (err: any) {
        console.error("AI Analysis error:", err);
        setErrorMsg("The AI service encountered a temporary hiccup. Please try again.");
      } finally {
        setIsAnalyzing(false);
        clearInterval(interval);
      }
    };
    reader.readAsDataURL(file);
  };

  // Reset analysis playground
  const handleReset = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setActiveAnalysis(null);
    setSelectedPresetId(null);
    setErrorMsg(null);
  };

  // Category labels helper
  const getCategoryLabel = (key: string) => {
    switch (key) {
      case "quality": return "Photo Quality";
      case "lighting": return "Lighting Setup";
      case "style": return "Professional Style";
      case "expression": return "Facial Expression";
      case "background": return "Background Clutter";
      case "approachability": return "Approachability Vibe";
      default: return key;
    }
  };

  const getCategoryColor = (key: string) => {
    switch (key) {
      case "quality": return "from-blue-500 to-indigo-500 text-blue-400 border-blue-500/20";
      case "lighting": return "from-amber-400 to-orange-400 text-amber-400 border-amber-400/20";
      case "style": return "from-indigo-500 to-purple-500 text-indigo-400 border-indigo-500/20";
      case "expression": return "from-purple-500 to-pink-500 text-purple-400 border-purple-500/20";
      case "background": return "from-rose-500 to-orange-500 text-rose-400 border-rose-500/20";
      case "approachability": return "from-teal-500 to-emerald-500 text-teal-400 border-teal-500/20";
      default: return "from-blue-500 to-indigo-500 text-blue-400 border-blue-500/20";
    }
  };

  return (
    <section id="demo" className="relative py-28 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Visual background lights */}
      <div className="absolute top-1/4 right-1/4 w-[600px] h-[600px] bg-blue-600/5 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/4 w-[500px] h-[500px] bg-indigo-500/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-xs font-semibold text-blue-500 uppercase tracking-widest font-mono mb-3">
            Interactive Workspace
          </h2>
          <p className="text-3xl sm:text-4xl font-bold font-display text-white tracking-tight">
            Analyze Your Presentation Instantly
          </p>
          <p className="text-gray-400 text-sm sm:text-base font-light mt-4">
            Drag and drop your own portrait or select one of our premium preset candidates below to experience our high-end, visual analysis engine.
          </p>
        </div>

        {/* Preset Selectors */}
        {!activeAnalysis && !isAnalyzing && (
          <div className="max-w-4xl mx-auto mb-12">
            <p className="text-xs font-mono text-gray-500 uppercase tracking-wider text-center mb-6">
              Or pick a professional profile to test
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {demoPresets.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => handlePresetSelect(preset)}
                  className={`
                    group text-left p-4 rounded-2xl border transition-all duration-300 backdrop-blur-md flex items-center space-x-4 cursor-pointer
                    ${selectedPresetId === preset.id 
                      ? "bg-blue-500/10 border-blue-500/40 shadow-[0_0_20px_rgba(59,130,246,0.15)]" 
                      : "bg-white/5 border-white/5 hover:bg-white/10 hover:border-white/10"
                    }
                  `}
                >
                  <div className="relative w-12 h-12 rounded-xl overflow-hidden border border-white/10 shrink-0">
                    <img src={preset.imageUrl} alt={preset.name} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h4 className="text-white text-sm font-semibold group-hover:text-blue-400 transition-colors">
                      {preset.name}
                    </h4>
                    <p className="text-gray-400 text-xs font-light">{preset.role}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Sandbox Core Container */}
        <div className="max-w-5xl mx-auto">
          <AnimatePresence mode="wait">
            
            {/* 1. Drag & Drop Upload Area */}
            {!activeAnalysis && !isAnalyzing && (
              <motion.div
                key="upload-state"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.4 }}
              >
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className={`
                    relative group border-2 border-dashed rounded-3xl p-12 flex flex-col items-center justify-center text-center transition-all duration-300 min-h-[360px] cursor-pointer
                    ${isDragOver 
                      ? "border-blue-500 bg-blue-500/5 shadow-[0_0_40px_rgba(59,130,246,0.1)]" 
                      : "border-white/10 bg-white/[0.02] hover:border-blue-500/40 hover:bg-white/[0.04]"
                    }
                  `}
                  onClick={() => fileInputRef.current?.click()}
                >
                  {/* Subtle inner accent glow */}
                  <div className="absolute inset-0 bg-radial-glow opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />
                  
                  {/* Floating camera icon sphere */}
                  <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:border-blue-500/30 group-hover:bg-blue-500/10 transition-all duration-300 relative overflow-hidden">
                    <Upload className="w-8 h-8 text-gray-400 group-hover:text-blue-400 transition-colors" />
                  </div>

                  <h3 className="text-xl font-semibold text-white tracking-tight mb-2">
                    Drag & Drop Your Portrait
                  </h3>
                  <p className="text-gray-400 text-sm font-light max-w-md mb-6 leading-relaxed">
                    Support JPEG, PNG, or WebP. Try uploading a LinkedIn avatar, social headshot, or close-up selfie for precise biometric scanning.
                  </p>

                  <button className="bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium px-6 py-3 rounded-xl transition-all duration-300 shadow-[0_0_15px_rgba(59,130,246,0.2)] hover:shadow-[0_0_25px_rgba(59,130,246,0.4)] flex items-center space-x-2">
                    <Camera className="w-4 h-4 text-blue-200" />
                    <span>Select Photo</span>
                  </button>

                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept="image/*"
                    className="hidden"
                  />

                  {/* Privacy badge */}
                  <div className="mt-8 flex items-center space-x-2 text-[11px] font-mono text-gray-500 uppercase tracking-widest bg-white/5 border border-white/5 px-3.5 py-1 rounded-full">
                    <Shield className="w-3.5 h-3.5 text-blue-400" />
                    <span>Privacy First: Images are instantly processed and deleted</span>
                  </div>
                </div>

                {/* Error Banner */}
                {errorMsg && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-4 p-4 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-center space-x-3 text-rose-300 text-sm text-left"
                  >
                    <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
                    <span>{errorMsg}</span>
                  </motion.div>
                )}
              </motion.div>
            )}

            {/* 2. Scanning / Loading State */}
            {isAnalyzing && (
              <motion.div
                key="loading-state"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="glass-card rounded-3xl p-12 flex flex-col items-center justify-center text-center min-h-[420px] relative border-white/5"
              >
                {/* Visual lasers / grids scanning */}
                <div className="absolute inset-0 bg-grid-pattern opacity-10 rounded-3xl pointer-events-none" />
                
                {/* Rotating holographic loader */}
                <div className="relative w-24 h-24 mb-8">
                  <div className="absolute inset-0 rounded-full border-2 border-dashed border-blue-500/30 animate-spin" style={{ animationDuration: "12s" }} />
                  <div className="absolute inset-2 rounded-full border border-double border-indigo-500/50 animate-spin" style={{ animationDuration: "6s", animationDirection: "reverse" }} />
                  <div className="absolute inset-4 rounded-full bg-blue-500/10 flex items-center justify-center">
                    <Sparkles className="w-8 h-8 text-blue-400 animate-pulse" />
                  </div>
                </div>

                <h3 className="text-2xl font-bold text-white tracking-tight mb-2 font-display">
                  Evaluating First Impression Parameters
                </h3>
                
                {/* Status message stream */}
                <div className="h-6 overflow-hidden max-w-lg mb-6">
                  <p className="text-blue-400 font-mono text-sm uppercase tracking-wider animate-pulse">
                    {analysisStatus}
                  </p>
                </div>

                {/* Simulated log console */}
                <div className="w-full max-w-md bg-black/60 border border-white/5 rounded-xl p-4 font-mono text-[10px] text-gray-500 text-left space-y-1.5 overflow-hidden">
                  <p className="text-blue-500/70">{`[system] connecting to gemini-3.5-flash server...`}</p>
                  <p className="text-gray-600">{`[biometrics] eye-gaze angle calibration ... ok`}</p>
                  <p className="text-gray-600">{`[lighting] contrast value ratio calculated ... ok`}</p>
                  <p className="text-blue-400/80 font-semibold">{`>> analyzing micro-indicators...`}</p>
                </div>
              </motion.div>
            )}

            {/* 3. Finished Results Dashboard */}
            {activeAnalysis && !isAnalyzing && (
              <motion.div
                key="results-state"
                initial={{ opacity: 0, y: 25 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start text-left"
              >
                
                {/* Left: Sticky image & circular score summary */}
                <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-28">
                  <GlassCard className="p-0 overflow-hidden border-white/5 bg-zinc-950/20 relative">
                    {/* Portrait Frame */}
                    <div className="relative h-64 sm:h-80 w-full overflow-hidden border-b border-white/5 bg-black">
                      {previewUrl && (
                        <img 
                          src={previewUrl} 
                          alt="Analyzed subject" 
                          className="w-full h-full object-cover object-center"
                        />
                      )}
                      
                      {/* Premium Scan Tag overlay */}
                      <div className="absolute top-4 left-4 bg-blue-600 text-[10px] font-mono uppercase tracking-widest text-white px-3 py-1 rounded-lg shadow-lg flex items-center space-x-1.5">
                        <Check className="w-3.5 h-3.5" />
                        <span>Analysis Confirmed</span>
                      </div>
                    </div>

                    {/* Overall Score Circle details */}
                    <div className="p-6 flex items-center justify-between">
                      <div>
                        <h3 className="text-white font-bold text-lg font-display">Overall Impression</h3>
                        <p className="text-xs text-gray-400 font-mono mt-0.5">Calculated score indices</p>
                      </div>

                      {/* SVG Gauge */}
                      <div className="relative w-24 h-24 flex items-center justify-center shrink-0">
                        <svg className="w-full h-full transform -rotate-90">
                          <circle cx="48" cy="48" r="40" className="stroke-zinc-800" strokeWidth="6" fill="transparent" />
                          <motion.circle
                            cx="48"
                            cy="48"
                            r="40"
                            className="stroke-blue-500"
                            strokeWidth="6"
                            fill="transparent"
                            strokeDasharray={2 * Math.PI * 40}
                            initial={{ strokeDashoffset: 2 * Math.PI * 40 }}
                            animate={{ strokeDashoffset: 2 * Math.PI * 40 * (1 - activeAnalysis.scores.overall / 10) }}
                            transition={{ duration: 1.5, ease: "easeOut" }}
                            strokeLinecap="round"
                          />
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                          <span className="text-2xl font-bold text-white font-display leading-none">
                            {activeAnalysis.scores.overall.toFixed(1)}
                          </span>
                          <span className="text-[9px] text-gray-500 font-mono tracking-tight uppercase mt-0.5">Index</span>
                        </div>
                      </div>
                    </div>

                    {/* Premium Executive Overall Summary */}
                    <div className="px-6 pb-6 pt-2">
                      <div className="bg-white/5 border border-white/5 rounded-xl p-4 text-xs font-light leading-relaxed text-gray-300 relative">
                        <div className="absolute -top-3 left-4 bg-zinc-900 px-2 text-[10px] text-blue-400 font-mono uppercase tracking-widest">
                          Executive Summary
                        </div>
                        <p className="mt-1">
                          {activeAnalysis.summary}
                        </p>
                      </div>
                    </div>
                  </GlassCard>

                  {/* Re-analyze Button */}
                  <button
                    onClick={handleReset}
                    className="w-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 text-white font-semibold py-4 rounded-xl transition-all duration-300 flex items-center justify-center space-x-2 backdrop-blur-md cursor-pointer"
                  >
                    <RefreshCw className="w-4 h-4 text-gray-400" />
                    <span>Upload New Photo</span>
                  </button>
                </div>

                {/* Right: Detailed Analysis Breakdown & Explanation cards */}
                <div className="lg:col-span-7 space-y-6">
                  
                  {/* Explanation card section */}
                  <div className="flex flex-col text-left">
                    <h3 className="text-xl font-bold text-white font-display mb-1.5 flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-blue-400" />
                      Detailed Parameter Feedback
                    </h3>
                    <p className="text-gray-400 text-xs font-light mb-6">
                      Click on any specific categories to inspect detailed biometrics, visual findings, and custom actionable tips.
                    </p>

                    {/* Parameters grid block list */}
                    <div className="space-y-4">
                      {Object.entries(activeAnalysis.categories).map(([key, cat]) => {
                        const category = cat as ScoreDetails;
                        const tabColor = getCategoryColor(key);
                        const label = getCategoryLabel(key);
                        
                        return (
                          <motion.div
                            key={key}
                            initial={{ opacity: 0, y: 15 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            className="bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 hover:border-white/10 rounded-2xl p-5 transition-all duration-300"
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                              {/* Label & Score Badge */}
                              <div className="flex items-center space-x-3">
                                <span className={`text-xs font-mono font-medium tracking-wider uppercase border rounded-lg px-2.5 py-1 ${tabColor}`}>
                                  {label}
                                </span>
                              </div>
                              {/* Score readout */}
                              <div className="flex items-baseline space-x-1.5">
                                <span className="text-2xl font-bold text-white font-display leading-none">
                                  {category.score.toFixed(1)}
                                </span>
                                <span className="text-xs text-gray-500 font-mono uppercase">/10</span>
                              </div>
                            </div>

                            {/* Filling parameter bar */}
                            <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden mb-4">
                              <motion.div
                                className={`h-full bg-gradient-to-r ${getCategoryColor(key).split(" ")[0]}`}
                                initial={{ width: "0%" }}
                                whileInView={{ width: `${category.score * 10}%` }}
                                viewport={{ once: true }}
                                transition={{ duration: 1, ease: "easeOut" }}
                              />
                            </div>

                            {/* Detailed Feedback explanation */}
                            <p className="text-gray-300 text-sm font-light leading-relaxed mb-4">
                              {category.feedback}
                            </p>

                            {/* Improvements recommendations list */}
                            <div className="pt-3.5 border-t border-white/5">
                              <p className="text-[10px] font-mono text-blue-400 uppercase tracking-widest mb-2.5 flex items-center gap-1.5">
                                <TrendingUp className="w-3.5 h-3.5" />
                                Actionable Improvements
                              </p>
                              <ul className="space-y-2">
                                {category.tips.map((tip, tIdx) => (
                                  <li key={tIdx} className="flex items-start space-x-2.5 text-xs text-gray-400 font-light leading-relaxed">
                                    <Check className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                                    <span>{tip}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </motion.div>
                        );
                      })}
                    </div>
                  </div>

                </div>

              </motion.div>
            )}

          </AnimatePresence>
        </div>

      </div>
    </section>
  );
}
