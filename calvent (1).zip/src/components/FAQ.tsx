import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronDown, HelpCircle } from "lucide-react";
import GlassCard from "./GlassCard";

interface FAQItemProps {
  question: string;
  answer: string;
  isOpen: boolean;
  onClick: () => void;
  key?: any;
}

function FAQAccordionItem({ question, answer, isOpen, onClick }: FAQItemProps) {
  return (
    <div className="border-b border-white/5 py-4">
      <button
        onClick={onClick}
        className="w-full flex items-center justify-between text-left py-2 font-medium text-white hover:text-blue-400 transition-colors cursor-pointer group"
      >
        <span className="text-base sm:text-lg tracking-tight font-display font-medium">
          {question}
        </span>
        <div className={`w-8 h-8 rounded-full bg-white/5 border border-white/5 flex items-center justify-center transition-all duration-300 group-hover:bg-blue-500/10 group-hover:border-blue-500/20 shrink-0 ${isOpen ? "rotate-180 text-blue-400" : "text-gray-400"}`}>
          <ChevronDown className="w-4 h-4" />
        </div>
      </button>

      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="overflow-hidden"
          >
            <p className="text-gray-400 text-sm font-light leading-relaxed pt-2 pb-4 pr-10">
              {answer}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: "Is my data private?",
      answer: "Absolutely. Security and privacy are integrated into our core infrastructure. Your uploaded images are processed entirely in encrypted memory buffers. We do not store, distribute, or use your portrait photographs to train model algorithms, and all uploads are permanently purged immediately after analysis is complete."
    },
    {
      question: "How accurate is the AI?",
      answer: "Calvent relies on top-tier multimodal vision frameworks (powered by Google Gemini 3.5 Flash) trained on thousands of professional portraits, composition rules, lighting principles, and expert corporate presentation standards. While scores are highly objective and based on validated design metrics, they are intended as advisory recommendations to help maximize your professional presence."
    },
    {
      question: "How long does analysis take?",
      answer: "Our pipeline is optimized for maximum performance. A full-scale analysis takes between 2 and 4 seconds from the moment you upload or drop your file. You receive complete circular scores, visual sub-indicator bars, and custom actionable advice immediately."
    },
    {
      question: "Can I upload multiple photos?",
      answer: "Yes. In the full platform, you can select up to 5 photos concurrently to run comparative scores. This is highly useful for comparing different jackets, backdrops, lighting scenarios, or expressions (such as a warm grin vs. a composed straight face) to decide which is your absolute strongest photo."
    }
  ];

  const handleToggle = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="relative py-24 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-indigo-500/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-4xl mx-auto relative z-10">
        
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-xs font-semibold text-blue-500 uppercase tracking-widest font-mono mb-3">
            Got Questions?
          </h2>
          <p className="text-3xl sm:text-4xl font-bold font-display text-white tracking-tight">
            Frequently Asked Questions
          </p>
          <p className="text-gray-400 text-sm font-light mt-4">
            Learn more about Calvent's privacy regulations, accuracy levels, processing pipelines, and capabilities.
          </p>
        </div>

        {/* Accordions Wrapper */}
        <GlassCard className="p-8 border-white/5 bg-zinc-950/20" delay={0.2}>
          <div className="divide-y divide-white/5">
            {faqs.map((faq, idx) => (
              <FAQAccordionItem
                key={faq.question}
                question={faq.question}
                answer={faq.answer}
                isOpen={openIndex === idx}
                onClick={() => handleToggle(idx)}
              />
            ))}
          </div>
        </GlassCard>

      </div>
    </section>
  );
}
