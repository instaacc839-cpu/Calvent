import { DemoPreset } from "../types";

export const demoPresets: DemoPreset[] = [
  {
    id: "julian",
    name: "Julian Vance",
    role: "VP of Product, Tech",
    imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=600&auto=format&fit=crop",
    result: {
      scores: {
        overall: 8.6,
        quality: 9.4,
        lighting: 9.0,
        style: 8.8,
        expression: 8.2,
        background: 8.5,
        approachability: 7.9,
      },
      categories: {
        quality: {
          score: 9.4,
          feedback: "Incredible image sharpness and pixel depth. Shot on a professional high-aperture lens with crisp focus on the eyes and perfect geometric centering.",
          tips: [
            "Your framing is exceptional; continue using this 85mm compression style for headshots.",
            "Avoid extreme close-up crops to retain natural shoulder-to-head proportion."
          ]
        },
        lighting: {
          score: 9.0,
          feedback: "Utilizes excellent 3-point studio lighting with soft key illumination, a subtle fill light on the opposite cheek, and clean rim highlights.",
          tips: [
            "Maintain this precise angle of key light (45 degrees) to keep a flattering soft shadow definition.",
            "Watch out for slight lens flare if the background rim light is placed too high."
          ]
        },
        style: {
          score: 8.8,
          feedback: "A crisp dark blazer paired with a clean neutral top conveys a high level of professional capability and strategic leadership.",
          tips: [
            "Consider introducing a subtle accent color (e.g. steel blue or forest green) to highlight personality.",
            "Ensure the shoulders are perfectly pressed without visible fabric wrinkles."
          ]
        },
        expression: {
          score: 8.2,
          feedback: "Gaze is confident and composed. Your slight smirk shows calm authority, though it can feel a bit reserved for some networks.",
          tips: [
            "Try a standard micro-smile with slightly raised lower eyelids to introduce a spark of charisma.",
            "Ensure your jawline remains relaxed to prevent the perception of dynamic tension."
          ]
        },
        background: {
          score: 8.5,
          feedback: "The soft, out-of-focus executive studio setting complements the professional subject perfectly without competing for viewer gaze.",
          tips: [
            "This bokeh level is ideal; continue using f/1.8 or f/2.0 apertures.",
            "Ensure no strong highlight spots are directly adjacent to your ears or hair."
          ]
        },
        approachability: {
          score: 7.9,
          feedback: "Julian projects highly competent, top-tier executive presence. The slight distance and formal pose trade a tiny bit of warmth for strong authority.",
          tips: [
            "An open body posture (shoulders angled slightly away from the camera) instantly improves conversational ease.",
            "For informal networks like LinkedIn, try pairing this with a warmer, more engaging smile."
          ]
        }
      },
      summary: "Your portrait excels in professional execution, boasting top-tier lighting and photographic sharpness. The composure projects deep executive authority, which can be made even more approachable with a softer smile and an angled shoulder posture."
    }
  },
  {
    id: "sophia",
    name: "Sophia Chen",
    role: "Creative Consultant",
    imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=600&auto=format&fit=crop",
    result: {
      scores: {
        overall: 8.9,
        quality: 9.1,
        lighting: 9.5,
        style: 9.2,
        expression: 8.9,
        background: 7.8,
        approachability: 9.2,
      },
      categories: {
        quality: {
          score: 9.1,
          feedback: "Superb details and highly accurate colors. Captured with a high-end camera, offering natural skin texture, clean highlights, and zero pixel artifacts.",
          tips: [
            "Keep using natural daytime exposure whenever possible for maximum texture depth.",
            "Ensure the auto-focus stays locked strictly on the eye closest to the camera lens."
          ]
        },
        lighting: {
          score: 9.5,
          feedback: "Beautiful golden hour lighting. The warm, diffused rays create soft gradients and a golden highlight on your hair, accentuating facial lines perfectly.",
          tips: [
            "This warm ambient tone is highly recommended; continue leveraging outdoor dusk lighting.",
            "Use a reflector or white card to bounce soft light onto the shadowed side of your face if needed."
          ]
        },
        style: {
          score: 9.2,
          feedback: "Your creative-chic attire conveys deep styling intelligence and personal brand alignment. Strong color contrast against the natural environment.",
          tips: [
            "This combination is stellar for creative, design, and marketing directories.",
            "Accessories are perfectly balanced and do not distract from your eyes."
          ]
        },
        expression: {
          score: 8.9,
          feedback: "Extremely natural, warm, and authentic smile. Direct and engaging eye contact conveys genuine warmth, passion, and collaborative spirit.",
          tips: [
            "This expression is your strongest asset; it is highly magnetic and memorable.",
            "Ensure your head tilt remains natural and doesn't bend too far sideways."
          ]
        },
        background: {
          score: 7.8,
          feedback: "The warm natural landscape is aesthetically pleasing, but some tree branches in the upper frame create minor geometric clutter.",
          tips: [
            "Take two steps forward to increase the subject-to-background distance, boosting background blur.",
            "Avoid objects in the background that align directly with your crown, creating a 'halo' effect."
          ]
        },
        approachability: {
          score: 9.2,
          feedback: "An outstanding approachability rating. You project deep creative authority, emotional intelligence, and immediate trustworthiness.",
          tips: [
            "This photo is highly optimized for client acquisition and friendly professional networking.",
            "For strict corporate portfolios, pair this energy with a slightly more structured jacket."
          ]
        }
      },
      summary: "Sophia projects an exceptionally warm and magnetic first impression, highlighted by gorgeous golden-hour lighting and an authentic smile. The creative style is perfect for modern directories, with just minor background details needing slight framing adjustments."
    }
  },
  {
    id: "liam",
    name: "Liam Martinez",
    role: "SaaS Founder",
    imageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=600&auto=format&fit=crop",
    result: {
      scores: {
        overall: 8.2,
        quality: 8.6,
        lighting: 8.1,
        style: 8.5,
        expression: 8.4,
        background: 6.9,
        approachability: 8.8,
      },
      categories: {
        quality: {
          score: 8.6,
          feedback: "Good smartphone portrait mode rendering. Edge detection around hair is relatively clean, though slightly blurry in intricate flyaway spots.",
          tips: [
            "To avoid portrait mode hair clipping, shoot against a background with contrasting colors.",
            "Wipe your smartphone camera clean to avoid soft light diffusion across your shot."
          ]
        },
        lighting: {
          score: 8.1,
          feedback: "Diffused outdoor lighting prevents harsh shadows. However, the light source is direct-overhead, causing slight shadows under the brow line.",
          tips: [
            "Angle your face 15 degrees upward to let natural sky-light illuminate your eyes completely.",
            "Seek light-colored concrete paths to act as natural bounce surfaces to fill in eye shadows."
          ]
        },
        style: {
          score: 8.5,
          feedback: "Smart-casual modern founder aesthetic (premium crewneck shirt under a minimalist jacket) conveys modern innovation and agility.",
          tips: [
            "This look is highly effective for tech, startups, and modern agency leadership.",
            "Add a structured collar layer if you are pitching to traditional venture funds."
          ]
        },
        expression: {
          score: 8.4,
          feedback: "A confident and friendly grin. Your expression feels authentic and shows high passion and approachability.",
          tips: [
            "This friendly posture is great. Continue focusing on natural laughter triggers.",
            "Relax your shoulders a tiny bit more to match the relaxed facial expression."
          ]
        },
        background: {
          score: 6.9,
          feedback: "The background represents a busy public space or office with visible light reflections and structures that divert visual focus.",
          tips: [
            "Choose a uniform wall, brick, or clean wood backdrop to keep visual focus 100% on you.",
            "Increase your distance from the background elements to blur them out more dramatically."
          ]
        },
        approachability: {
          score: 8.8,
          feedback: "Liam scores very high on approachability. He feels highly accessible, friendly, and energetic—like a modern collaborative partner.",
          tips: [
            "This is outstanding for startup building, tech recruiting, and community building.",
            "Consider a slightly more formal secondary headshot for high-profile press releases."
          ]
        }
      },
      summary: "Liam displays a highly approachable, modern startup founder vibe with great clothing style and a warm smile. The primary factor reducing his score is the distracting background, which can be improved by finding a simpler backdrop or increasing background blur."
    }
  }
];
