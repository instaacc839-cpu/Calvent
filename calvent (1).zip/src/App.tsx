import React from "react";
import { Sparkles, Camera, Shield, ShieldCheck } from "lucide-react";
import Hero from "./components/Hero";
import HowItWorks from "./components/HowItWorks";
import DemoSection from "./components/DemoSection";
import Features from "./components/Features";
import Testimonials from "./components/Testimonials";
import FAQ from "./components/FAQ";
import Footer from "./components/Footer";

export default function App() {
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="relative min-h-screen bg-bg-dark selection:bg-blue-500/30 selection:text-white">
      
      {/* Floating Sticky Header */}
      <header className="fixed top-0 inset-x-0 h-20 bg-zinc-950/40 backdrop-blur-md border-b border-white/5 z-50 flex items-center justify-between px-6 sm:px-12">
        {/* Brand identity */}
        <div className="flex items-center space-x-2 font-display font-bold text-xl tracking-wide text-white cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
          <span className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(59,130,246,1)]" />
          <span>Calvent</span>
        </div>

        {/* Navigation list */}
        <nav className="hidden md:flex items-center space-x-8 text-xs font-mono tracking-wider text-gray-400">
          <button onClick={() => scrollToSection("how-it-works")} className="hover:text-white transition-colors cursor-pointer">
            How It Works
          </button>
          <button onClick={() => scrollToSection("demo")} className="hover:text-white transition-colors cursor-pointer">
            Interactive Demo
          </button>
          <button onClick={() => scrollToSection("features")} className="hover:text-white transition-colors cursor-pointer">
            Features
          </button>
          <button onClick={() => scrollToSection("testimonials")} className="hover:text-white transition-colors cursor-pointer">
            Testimonials
          </button>
          <button onClick={() => scrollToSection("faq")} className="hover:text-white transition-colors cursor-pointer">
            FAQ
          </button>
        </nav>

        {/* Small header CTA */}
        <div>
          <button
            onClick={() => scrollToSection("demo")}
            className="bg-white/5 hover:bg-blue-500/10 border border-white/10 hover:border-blue-500/20 text-white hover:text-blue-400 text-xs font-mono tracking-wider px-5 py-2.5 rounded-xl transition-all duration-300 flex items-center space-x-2 cursor-pointer"
          >
            <Camera className="w-3.5 h-3.5 shrink-0" />
            <span>Launch Scanner</span>
          </button>
        </div>
      </header>

      {/* Main Single Page Content */}
      <main>
        {/* 1. Hero */}
        <Hero 
          onAnalyzeClick={() => scrollToSection("demo")} 
          onDemoClick={() => scrollToSection("demo")} 
        />

        {/* 2. How It Works */}
        <HowItWorks />

        {/* 3. Interactive Demo & Scanner Workspace */}
        <DemoSection />

        {/* 4. Features */}
        <Features />

        {/* 5. Testimonials */}
        <Testimonials />

        {/* 6. FAQ Accordions */}
        <FAQ />
      </main>

      {/* Minimal footer */}
      <Footer />
    </div>
  );
}
