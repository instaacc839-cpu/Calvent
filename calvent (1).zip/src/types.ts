export interface FeatureCard {
  title: string;
  description: string;
  iconName: string;
}

export interface Testimonial {
  name: string;
  role: string;
  image: string;
  quote: string;
  rating: number;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface AnalysisScores {
  overall: number;
  quality: number;
  lighting: number;
  style: number;
  expression: number;
  background: number;
  approachability: number;
}

export interface ScoreDetails {
  score: number;
  feedback: string;
  tips: string[];
}

export interface PhotoAnalysisResult {
  scores: AnalysisScores;
  categories: {
    quality: ScoreDetails;
    lighting: ScoreDetails;
    style: ScoreDetails;
    expression: ScoreDetails;
    background: ScoreDetails;
    approachability: ScoreDetails;
  };
  summary: string;
}

export interface DemoPreset {
  id: string;
  name: string;
  role: string;
  imageUrl: string;
  result: PhotoAnalysisResult;
}
